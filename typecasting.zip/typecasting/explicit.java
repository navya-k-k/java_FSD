package basicjava;

public class explicit {

	public static void main(String[] args) {
		
		 
		
		 
		        
		        double d = 120.00;
		        
		         long l = (long)d;
		        
		        int i = (int)l;
		 
		       
		        
		        System.out.println("Double " + d);
		 
		       
		        System.out.println("Long " + l);
		 
		        
		        System.out.println("Int" + i);
		    }
		

	

}
