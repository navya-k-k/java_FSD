package basicjava;

public class implicit {

	public static void main(String[] args) {byte b = 14;  
    System.out.println("value of b: "+b);  
    
    short a = b;  
    System.out.println("short : "+a);  
    int c = a;  
    System.out.println("int  : "+c);  
    long d = c;  
    System.out.println("long  : "+d);  
    float e = d;  
    System.out.println("float  : "+e);  
    double f = e;  
    System.out.println("double : "+f);
		

	}

}
