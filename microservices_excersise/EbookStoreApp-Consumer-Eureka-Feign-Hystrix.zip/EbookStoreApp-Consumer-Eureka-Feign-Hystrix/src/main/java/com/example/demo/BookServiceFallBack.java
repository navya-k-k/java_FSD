package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class BookServiceFallBack implements BookServiceProxy {

	@Override
	public List<Book> getAllBooks() {
		return new ArrayList<Book>();
	}

	@Override
	public Book getBookById(Integer id) {
		return new Book(id,"New Book","New publisher","985-856-741",365,2023);
	}

}
