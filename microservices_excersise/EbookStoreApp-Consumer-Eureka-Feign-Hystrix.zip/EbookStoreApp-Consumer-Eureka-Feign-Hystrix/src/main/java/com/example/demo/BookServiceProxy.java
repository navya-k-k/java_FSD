package com.example.demo;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name="book-service", fallback = BookServiceFallBack.class)
public interface BookServiceProxy {
	
	@GetMapping("/books")
	public List<Book> getAllBooks();
	
	@GetMapping("/books/{id}")
	public Book getBookById(@PathVariable("id") Integer id);

}
