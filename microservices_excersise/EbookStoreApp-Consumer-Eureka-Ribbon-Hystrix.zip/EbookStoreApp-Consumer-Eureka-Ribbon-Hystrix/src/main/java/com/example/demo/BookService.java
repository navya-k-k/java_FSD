package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class BookService {
	
	@Autowired
	private RestTemplate restTemplate;
	
	@HystrixCommand(fallbackMethod = "getBookByIdFallBackMethod")
	public Book getBookById(int id) {
		Book book= restTemplate.getForObject("http://book-service/books/"+id, Book.class);
		return book;
	}
	
	public Book getBookByIdFallBackMethod(int id) {
		
		return new Book(id,"New Book","New publisher","985-856-741",365,2023);
	}

}
