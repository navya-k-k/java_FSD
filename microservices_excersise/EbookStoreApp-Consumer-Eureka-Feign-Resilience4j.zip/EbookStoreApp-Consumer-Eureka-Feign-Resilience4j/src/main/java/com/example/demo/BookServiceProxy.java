package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name="book-service")
public interface BookServiceProxy {
	
	@Retry(name="book-service")
	@CircuitBreaker(name="book-service",fallbackMethod = "FallbackMethodGetAllBooks")
	@GetMapping("/books")
	public List<Book> getAllBooks();
	
	
	@Retry(name="book-service")
	@CircuitBreaker(name="book-service",fallbackMethod = "FallbackMethodGetBookById")
	@GetMapping("/books/{id}")
	public Book getBookById(@PathVariable("id") Integer id);
	
	public default List<Book> FallbackMethodGetAllBooks(Throwable cause) {
		System.out.println("exception raised with message= "+cause.getMessage());
		return new ArrayList<Book>();
	}

	public default Book FallbackMethodGetBookById(Integer id,Throwable cause) {
		System.out.println("exception raised with message= "+cause.getMessage());
		return new Book(id,"New Book","New publisher","985-856-741",365,2023);
	}

}
