package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Book {
	@Id
	@Column(name="id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name="BookTitle")
	private String title;
	
	@Column(name="BookPublisher")
	private String publisher;
	
	@Column(name="BookIsbn")
	private String isbn;
	
	@Column(name="BookNumberOfPages")
	private int pages;
	
	@Column(name="BookYear")
	private int year;
}
