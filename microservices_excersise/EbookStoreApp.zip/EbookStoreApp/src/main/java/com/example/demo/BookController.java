package com.example.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Scope(value = "request")
public class BookController {

	@Autowired
	BookDAO dao;
	
	@PostMapping("/books")
	public Book addBook(@RequestBody Book book) {
		return dao.addbook(book);
	}
	
	@PutMapping("/books")
	public Book updateBook(@RequestBody Book book) {
		return dao.updatebook(book);
	}
	
	@GetMapping("/books")
	public List<Book> getAllBooks() {
		return dao.getallbooks();
	}
	
	@GetMapping("/books/{id}")
	public Optional<Book> getBookById(@PathVariable("id") Integer id) {
		return dao.findbookbyid(id);
	}
	
	@DeleteMapping("/books/{id}")
	public void deleteBookById(@PathVariable("id") Integer id) {
		dao.deletebookbyid(id);
	}
	
	@GetMapping("/books/title/{book_title}")
	public List<Book> getBookByTitle(@PathVariable("book_title") String title) {
		return dao.findBookbyName(title);
	}
	
	@GetMapping("/books/publisher/{book_publisher}")
	public List<Book> getBookByPublisher(@PathVariable("book_publisher") String publisher){
		return dao.findBookbyPublisher(publisher);
	}
	

}
