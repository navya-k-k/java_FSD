package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
import org.springframework.context.annotation.Bean;

@EnableZuulProxy
@SpringBootApplication
public class EbookStoreAppProxyApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EbookStoreAppProxyApiApplication.class, args);
	}

	@Bean
	public PreFilter getPreFilter() {
		return new PreFilter();
	}
	
	@Bean
	public PostFilter getPostFilter() {
		return new PostFilter();
	}
	
	@Bean
	public RouteFilter getRouteFilter() {
		return new RouteFilter();
	}
	
	@Bean
	public ErrorFilter getErrorFilter() {
		return new ErrorFilter();
	}
}
