package pkg2;

import pkg.*;

public class newtwo {
public static void main(String[] args) {
		
		newcls obj = new newcls(); 
        obj.display();  

}
}
