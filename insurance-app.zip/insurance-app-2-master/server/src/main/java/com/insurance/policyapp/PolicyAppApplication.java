package com.insurance.policyapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PolicyAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(PolicyAppApplication.class, args);
	}

}
