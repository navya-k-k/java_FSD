package com.insurance.policyapp.dto;

public class AnswerQuestionRequest {
	private String answerText;

	public AnswerQuestionRequest() {
		super();
	}

	public String getAnswerText() {
		return answerText;
	}

	public void setAnswerText(String answerText) {
		this.answerText = answerText;
	}
	
}
