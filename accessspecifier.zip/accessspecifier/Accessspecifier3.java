package basicjava;

public class Accessspecifier3 {

    protected String name;

    protected Accessspecifier3(String name) {
        this.name = name;
    }

    protected String getName() {
        return name;
    }
}



